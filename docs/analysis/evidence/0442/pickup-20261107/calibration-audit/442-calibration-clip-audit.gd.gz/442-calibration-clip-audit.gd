extends SceneTree
# Read-only comparison using documented Animation track API.
# https://docs.godotengine.org/en/4.7/classes/class_animation.html
func _initialize() -> void:
    var output := {}
    for path in ["res://.godot/442-calibration-baseline-locomotion.res", "res://assets/locomotion.res"]:
        var lib: AnimationLibrary = load(path)
        assert(lib != null, "Could not load " + path)
        var rows := {}
        for clip in lib.get_animation_list():
            if "jumpshot" not in str(clip).to_lower() and "fadeaway" not in str(clip).to_lower():
                continue
            var animation := lib.get_animation(clip)
            var tracks := []
            for track in animation.get_track_count():
                var keys := []
                for key in animation.track_get_key_count(track):
                    keys.append([animation.track_get_key_time(track, key),
                        var_to_str(animation.track_get_key_value(track, key)),
                        animation.track_get_key_transition(track, key)])
                tracks.append({"path":str(animation.track_get_path(track)),
                    "type":animation.track_get_type(track),
                    "interpolation":animation.track_get_interpolation_type(track),
                    "loop_wrap":animation.track_get_interpolation_loop_wrap(track),
                    "enabled":animation.track_is_enabled(track),"keys":keys})
            rows[str(clip)] = {"length":animation.length,"step":animation.step,
                "loop_mode":animation.loop_mode,"tracks":tracks}
        output[path] = rows
    var file := FileAccess.open("res://.godot/442-calibration-clip-audit.json", FileAccess.WRITE)
    file.store_string(JSON.stringify(output,"\t"))
    print("[clip-audit] wrote .godot/442-calibration-clip-audit.json")
    quit(0)
