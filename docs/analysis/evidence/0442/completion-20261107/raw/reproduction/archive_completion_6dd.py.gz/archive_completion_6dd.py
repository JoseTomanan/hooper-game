"""Archive completed #442 sources without rewriting their original bytes.

Run archive-ci only after the corresponding artifact download has completed.
Run finalize only after both shard inventories exist. Verification inputs are
explicit stable files supplied after the orchestrator's completion notice.
"""
from __future__ import annotations

import argparse
from collections import Counter
import gzip
import hashlib
import itertools
import json
import re
import subprocess
import importlib.util
import sys
from pathlib import Path

ROOT = next(path for path in Path(__file__).resolve().parents if (path / "project.godot").is_file())
OUT = ROOT / "docs/analysis/evidence/0442/completion-20261107"
RUN = 42381239530
SOURCE = "6dd8e4de521cdd3cf0536648ffbb52c665ee8c42"
PRODUCTION = "ba324a6a4622b1fae34879d44ee176f259cb00d7"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def expected(shard=None):
    result = set()
    for hand, entry, variant, offset in itertools.product(
            ("right", "left"), ("held", "dribble", "moving"),
            ("normal", "early", "late"), (0, 7)):
        stem = f"{hand}-{entry}-{variant}-o{offset}-1"
        if shard in (None, 2):
            result.add((stem, "local"))
        if shard is None or offset == (0 if shard == 2 else 7):
            result.update(((stem, "observer"), (stem + "-owner", "owner")))
    return result


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def archive(source, relative, origin):
    source = source.resolve()
    target = OUT / "raw" / (relative + ".gz")
    if not source.is_file() or not source.is_relative_to(ROOT / ".godot"):
        raise ValueError("Invalid source: " + str(source))
    before = source.stat()
    data = source.read_bytes()
    after = source.stat()
    if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
        raise ValueError("Changing source: " + str(source))
    target.parent.mkdir(parents=True, exist_ok=True)
    # Empty filename and zero mtime make gzip bytes reproducible. Existing
    # evidence is checked, never silently replaced by a different source.
    # GzipFile provides the explicit empty-filename contract consistently.
    import io
    buffer = io.BytesIO()
    with gzip.GzipFile(filename="", fileobj=buffer, mode="wb", compresslevel=9, mtime=0) as output:
        output.write(data)
    compressed = buffer.getvalue()
    if len(compressed) >= 100_000_000:
        raise ValueError("Archive reaches GitHub's 100 MB file limit: " + relative)
    if target.exists() and target.read_bytes() != compressed:
        raise ValueError("Refusing to overwrite different evidence: " + str(target))
    target.write_bytes(compressed)
    if gzip.decompress(target.read_bytes()) != data:
        raise ValueError("Decompressed bytes differ: " + str(target))
    return {"source": source.relative_to(ROOT).as_posix(), "sourceBytes": len(data),
            "sourceSha256": digest(data), "archive": target.relative_to(OUT).as_posix(),
            "archiveBytes": len(compressed), "archiveSha256": digest(compressed),
            "gzipFilename": "", "gzipMtime": 0, "origin": origin}


def load_cases(root):
    cases, summaries, report_paths = [], [], set()
    for summary_path in sorted(root.rglob("summary.json")):
        summary = read(summary_path)
        if summary.get("result") != "passed" or summary.get("failures") != []:
            raise ValueError("Red/incomplete summary: " + str(summary_path))
        group = []
        reports = sorted(summary_path.parent.glob("*-proof.json"))
        if not reports:
            raise ValueError("Summary without role report: " + str(summary_path))
        for path in reports:
            report = read(path)
            if report.get("result") != "passed":
                raise ValueError("Red report: " + str(path))
            report_paths.add(path)
            group.extend(report["cases"])
        if len(group) != summary["cases"]:
            raise ValueError("Summary/report case mismatch: " + str(summary_path))
        for case in group:
            if case.get("result") != "passed" or case.get("failures") != []:
                raise ValueError("Red case: " + str((case.get("case"), case.get("role"))))
            # Preserve full original reports; these references only identify
            # which original report supplied the derived aggregation.
            cases.append(case)
        summaries.append(summary_path.relative_to(root).as_posix())
    if report_paths != set(root.rglob("*-proof.json")):
        raise ValueError("Unpaired role report in artifact")
    return cases, summaries


def validate_identities(cases, wanted):
    identities = [(c["case"], c["role"]) for c in cases]
    if len(identities) != len(wanted) or set(identities) != wanted:
        raise ValueError(f"Incomplete/duplicate case matrix: got {len(identities)}, expected {len(wanted)}; "
                         f"missing={sorted(wanted-set(identities))}; extra={sorted(set(identities)-wanted)}")


def ci(args):
    if not args.download_complete:
        raise ValueError("Do not archive changing downloads; wait for parent completion notice")
    OUT.mkdir(parents=True, exist_ok=True)
    root = args.source.resolve()
    if not root.is_dir() or not root.is_relative_to(ROOT / ".godot"):
        raise ValueError("Artifact source must be below .godot")
    cases, summaries = load_cases(root)
    validate_identities(cases, expected(args.shard))
    manifests = [(p, read(p)) for p in root.rglob("manifest.json")]
    for case in cases:
        matches = [(p, m) for p, m in manifests if p.parent.name == case["case"] and m.get("role") == case["role"]]
        if len(matches) != 1 or matches[0][1].get("result") != "captured" or not (matches[0][0].parent / "trace.jsonl").is_file():
            raise ValueError("Missing/ambiguous original case trace/manifest: " + str((case["case"], case["role"])))
    origin = {"repository": "JoseTomanan/hooper-game", "ciRun": RUN, "runAttempt": 1,
              "runUrl": f"https://github.com/JoseTomanan/hooper-game/actions/runs/{RUN}",
              "artifactId": args.artifact_id, "artifactName": f"shot-attachment-proof-{RUN}-1-shard-{args.shard}",
              "artifactDownloadSizeBytes": args.artifact_size,
              "artifactApiUrl": f"https://api.github.com/repos/JoseTomanan/hooper-game/actions/artifacts/{args.artifact_id}",
              "sourcePullRequestHead": SOURCE, "shard": args.shard}
    files = sorted(p for p in root.rglob("*") if p.is_file())
    skipped_png = [p.relative_to(root).as_posix() for p in files if p.suffix.lower() == ".png"]
    records = [archive(p, f"ci/shard-{args.shard}/" + p.relative_to(root).as_posix(), origin)
               for p in files if p.suffix.lower() != ".png"]
    part = {"schema": "hooper-442-ci-artifact-archive/v1", "scope": "partial matrix; full acceptance requires both shard inventories",
            "origin": origin, "downloadRoot": root.relative_to(ROOT).as_posix(), "summaries": summaries,
            "cases": len(cases), "roles": dict(Counter(c["role"] for c in cases)),
            "captureCheckoutCommits": sorted({m.get("commit") for _, m in manifests}),
            "caseIdentities": sorted([list(i) for i in expected(args.shard)]), "skippedPng": skipped_png,
            "files": records}
    save(f"artifact-shard-{args.shard}-index.json", part)
    print(json.dumps({k: part[k] for k in ("scope", "cases", "roles", "captureCheckoutCommits")}, indent=2))
    print("Archived", len(records), "original files; compressed bytes", sum(r["archiveBytes"] for r in records), flush=True)


def metrics(cases):
    maximum = lambda values: max(values, default=0)
    return {"maxPalmSurfaceErrorM": maximum(p["contactErrorM"] for c in cases for p in c["contactFrames"]),
            "maxPhysicalModelErrorM": maximum(p.get("physicalModelErrorM", 0) for c in cases for p in c["contactFrames"]),
            "maxReleaseModelErrorM": maximum(c["release"].get("releaseModelErrorM", 0) for c in cases),
            "maxFlightPositionErrorM": maximum(p["positionErrorM"] for c in cases for p in c["firstFlightFrames"]),
            "maxFlightVelocityErrorMPerS": maximum(p["velocityErrorMPerS"] for c in cases for p in c["firstFlightFrames"]),
            "maxSegmentLengthChangeM": maximum(p["maxChangeM"] for c in cases for p in c["limbDimensions"].values()),
            "maxFakePhysicalModelErrorM": maximum(p.get("physicalModelErrorM", 0) for c in cases for p in c["fakeAttachmentFrames"]),
            "maxFakeVisualCorrectionResidualM": maximum(p["visualCorrectionResidualM"] for c in cases for p in c["fakeAttachmentFrames"]),
            "maxFakeNeutralHandoffResidualM": maximum(c["fakeReturnBoundary"].get("handoffResidualM", 0) for c in cases)}


def gate_snapshot(status_path, checks_path):
    status, checks = read(status_path), read(checks_path)
    if (status.get("databaseId") != RUN or status.get("headSha") != SOURCE
            or status.get("status") != "completed" or status.get("conclusion") != "success"):
        raise ValueError("Source CI is still pending/not green or belongs to another head/run")
    jobs = status.get("jobs", [])
    if len(jobs) != 9 or any(j.get("status") != "completed" or j.get("conclusion") != "success" for j in jobs):
        raise ValueError("All nine original CI job conclusions must be completed/success")
    if isinstance(checks, dict):
        checks = checks.get("checks", checks.get("statusCheckRollup"))
    if (not isinstance(checks, list) or len(checks) != 9
            or any(c.get("state", c.get("conclusion", "")).lower() != "success" for c in checks)):
        raise ValueError("Explicit nine-green-check snapshot is missing/incomplete")
    return status, checks


def catalog_evidence(shard_logs):
    if len(shard_logs) != 4 or {int(n) for n, _ in shard_logs} != {1, 2, 3, 4}:
        raise ValueError("Require exactly one completed original job log for each shard 1..4")
    module_path = ROOT / "tools/harness_catalog.py"
    git_source = subprocess.check_output(["git", "show", SOURCE + ":tools/harness_catalog.py"], cwd=ROOT)
    if module_path.read_text(encoding="utf-8").splitlines() != git_source.decode("utf-8").splitlines():
        raise ValueError("Current catalog differs from the tested source PR head")
    spec = importlib.util.spec_from_file_location("harness_catalog_completion", module_path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    wanted = {case.id for case in module.CATALOG}
    if len(wanted) != 486:
        raise ValueError("Source catalog no longer has this completion's 486 cases")
    observed, shards = [], []
    for shard_number, path in sorted(shard_logs, key=lambda x: int(x[0])):
        text = path.read_text(encoding="utf-8", errors="strict")
        totals = re.findall(r"RESULT: (\d+) passed / (\d+) run", text)
        if len(totals) != 1 or totals[0][0] != totals[0][1]:
            raise ValueError("Missing/nonpassing original exhaustive shard verdict: " + str(path))
        ids = re.findall(r"\bPASS\s+([a-z0-9-]+)\s+log=", text)
        if len(ids) != int(totals[0][0]) or len(set(ids)) != len(ids):
            raise ValueError("Original shard result identities do not match its exact verdict count")
        observed.extend(ids)
        shards.append({"shard": int(shard_number), "passed": int(totals[0][0]),
                       "run": int(totals[0][1]), "caseIds": ids,
                       "sourceLog": path.resolve().relative_to(ROOT).as_posix()})
    if len(observed) != len(wanted) or set(observed) != wanted:
        raise ValueError("Original four-shard logs do not prove each source catalog case exactly once")
    return {"result": "passed", "cases": len(observed), "sourceCatalogGitBlobSha256": digest(git_source),
            "shards": shards}


def build_evidence(path):
    text = path.read_text(encoding="utf-8")
    unit = re.search(r"Passed!\s*-\s*Failed:\s*(\d+),\s*Passed:\s*(\d+),\s*Skipped:\s*(\d+),\s*Total:\s*(\d+)", text)
    repository = re.search(r"Ran (\d+) tests in", text)
    repository_ok = re.search(r"\bOK(?: \(skipped=(\d+)\))?(?:\r?\n|$)", text)
    if not unit or not repository or not repository_ok or int(unit[1]) != 0:
        raise ValueError("Original build job lacks passing full unit/repository verdicts")
    return {"unit": {"failed": int(unit[1]), "passed": int(unit[2]), "skipped": int(unit[3]), "total": int(unit[4])},
            "repository": {"run": int(repository[1]), "skipped": int(repository_ok[1] or 0), "result": "passed"}}


def finalize(args):
    status, checks = gate_snapshot(args.status, args.checks)
    catalog = catalog_evidence(args.shard_log)
    build = build_evidence(args.build_log)
    if not (OUT / "artifact-shard-2-index.json").is_file() or not (OUT / "artifact-shard-3-index.json").is_file():
        raise ValueError("Both completed artifact inventories are required")
    parts = [read(OUT / f"artifact-shard-{shard}-index.json") for shard in (2, 3)]
    cases, records, checkout_commits = [], [], set()
    for part in parts:
        if part["origin"]["ciRun"] != RUN or part["origin"]["sourcePullRequestHead"] != SOURCE:
            raise ValueError("Artifact inventory belongs to another CI run/head")
        group, _ = load_cases(ROOT / part["downloadRoot"])
        validate_identities(group, expected(part["origin"]["shard"]))
        cases.extend(group)
        records.extend(part["files"])
        checkout_commits.update(part["captureCheckoutCommits"])
        for record in part["files"]:
            compressed = (OUT / record["archive"]).read_bytes()
            data = gzip.decompress(compressed)
            if (digest(compressed) != record["archiveSha256"] or len(compressed) != record["archiveBytes"]
                    or digest(data) != record["sourceSha256"] or len(data) != record["sourceBytes"]):
                raise ValueError("Original-byte archive verification failed: " + record["archive"])
    validate_identities(cases, expected())
    if len(checkout_commits) != 1 or any(not isinstance(c, str) or not re.fullmatch(r"[0-9a-f]{40}", c) for c in checkout_commits):
        raise ValueError("Expected one original CI checkout/merge SHA across capture manifests")
    origin = {"ciRun": RUN, "sourcePullRequestHead": SOURCE, "kind": "original completed CI verdict/log"}
    gate_files = [(args.status, "ci-run-status.json"), (args.checks, "pr-checks.json"), (args.build_log, "build-and-test.log")]
    gate_files += [(path, f"integration-shard-{n}.log") for n, path in args.shard_log]
    gate_records = [archive(path, "ci-verdicts/" + name, origin) for path, name in gate_files]
    script_record = archive(Path(__file__), "reproduction/archive_completion_6dd.py", {"kind": "original packaging script"})
    result = {"schema": "hooper-shot-attachment-completion/v3", "sourcePullRequestHead": SOURCE,
              "productionCodeHead": PRODUCTION, "ciRun": RUN, "sourceCiOverall": "completed/success",
              "ciRunUrl": f"https://github.com/JoseTomanan/hooper-game/actions/runs/{RUN}",
              "jobs": [{k: j.get(k) for k in ("databaseId", "name", "status", "conclusion", "url")} for j in status["jobs"]],
              "greenChecks": len(checks), "catalog": catalog, "buildAndTest": build,
              "captureCheckoutMergeCommits": sorted(checkout_commits),
              "captureCommitMeaning": "Original manifests retain the GitHub checkout/merge commit; it is distinct from the source PR head.",
              "attachment": {"result": "passed", "cases": len(cases), "roles": dict(Counter(c["role"] for c in cases)), **metrics(cases)},
              "artifacts": [{"index": f"artifact-shard-{p['origin']['shard']}-index.json", "origin": p["origin"]} for p in parts],
              "archiveTotals": {"ciOriginalFiles": len(records), "ciOriginalBytes": sum(r["sourceBytes"] for r in records),
                                "ciArchiveBytes": sum(r["archiveBytes"] for r in records)},
              "verdictRecords": gate_records, "packagingScript": script_record,
              "localVerificationPackage": "../fake-return-20261107/README.md",
              "historicalClassification": "Earlier e202 attachment archives are superseded historical diagnostics. Earlier local exhaustive attempt stopped at 350/484 and never proved a full local sweep.",
              "interpretation": "All 108 exact role cases and original source reports pass. All nine original source-head CI jobs/checks are green; four original shard logs prove all 486 source catalog cases exactly once. No threshold or source report was rewritten. Appearance/feel remains #173."}
    save("completion-summary.json", result)
    (OUT / "README.md").write_text(
        "# #442 current completion evidence — 2026-11-07\n\n"
        f"Source PR head `{SOURCE}` passed all **nine checks** in [CI run {RUN}](https://github.com/JoseTomanan/hooper-game/actions/runs/{RUN}). "
        "The original four shard logs prove **486/486 catalog cases**, each once. Original run/check snapshots and job logs are archived under `raw/ci-verdicts/`; "
        "[completion summary](completion-summary.json) records exact job verdicts, unit/repository counts, catalog identities and unchanged report metrics.\n\n"
        "The current attachment matrix contains **108 passing role cases: local 36, predicted owner 36, separate observer 36**. "
        "Both artifact downloads finished before copying. Every source summary/report is passed, every case's failures list is empty, exact expected identities occur once, "
        "and every case resolves to its original manifest and trace. [Shard 2 inventory](artifact-shard-2-index.json) covers local36 plus owner/observer offset0; "
        "[shard 3 inventory](artifact-shard-3-index.json) covers owner/observer offset7. Actual original manifest checkout/merge SHAs are retained, never rewritten as the PR head.\n\n"
        "Every non-PNG original artifact file is preserved under `raw/ci/`, including raw traces/manifests/reports/process logs. Any skipped PNGs are explicitly listed. "
        "Each deterministic gzip uses an empty filename and mtime0. Inventories record original-byte and archive SHA256, sizes, artifact ID/download size, run and source-head provenance; "
        "all decompressed bytes and both hashes/sizes were independently checked. The packaging script is archived under `raw/reproduction/`. "
        "Stable-source commands: `python .godot/442-current-20261107/archive_completion_6dd.py archive-ci --help` and `finalize --help`.\n\n"
        "Current local builds, full eight-case remote form proof, all eight block outcomes, reciprocal old-station mutation/red-green proof and the local36 attachment matrix "
        "are preserved in the separate [fake-return verification package](../fake-return-20261107/README.md); they are linked rather than copied here. "
        "Earlier e202 archives and numerical-only owner reanalysis remain superseded diagnostics. The earlier local full-sweep attempt stopped at350/484 and is nonexhaustive. "
        "The separately packaged observer film is after-only and its owning-client film remains rejected. Appearance/feel remains unaccepted in #173.\n", encoding="utf-8")
    print(json.dumps({"attachment": result["attachment"], "archiveTotals": result["archiveTotals"], "catalog": catalog["cases"]}, indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    part = commands.add_parser("archive-ci")
    part.add_argument("--source", type=Path, required=True)
    part.add_argument("--shard", type=int, choices=(2, 3), required=True)
    part.add_argument("--artifact-id", type=int, required=True)
    part.add_argument("--artifact-size", type=int, required=True)
    part.add_argument("--download-complete", action="store_true")
    final = commands.add_parser("finalize")
    final.add_argument("--status", type=Path, required=True)
    final.add_argument("--checks", type=Path, required=True)
    final.add_argument("--build-log", type=Path, required=True)
    final.add_argument("--shard-log", nargs=2, action="append", metavar=("SHARD", "PATH"), required=True)
    args = parser.parse_args()
    if args.command == "archive-ci":
        ci(args)
    else:
        args.shard_log = [(int(n), Path(path)) for n, path in args.shard_log]
        finalize(args)


if __name__ == "__main__":
    main()


