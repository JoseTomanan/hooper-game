from pathlib import Path
import hashlib
import json
import os
import subprocess

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
SOURCE = ROOT / 'scripts/Ball/BallController.cs'
LEDGER = OUT / 'corrected-origin-mutation-ledger.json'
report = {'schema': 'hooper-corrected-origin-mutation/v1',
          'headAtStart': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
          'mutation': 'omit only TickHeld ApplyShotGather(holderBody), retaining old fixed Held root',
          'events': []}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save():
    LEDGER.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')

def build(label):
    cmd = ['dotnet', 'build', 'HOOPER GAME.csproj', '-p:IncludeIntegrationHarness=true']
    logfile = OUT / (label + '-build.log')
    with logfile.open('w', encoding='utf-8') as stream:
        result = subprocess.run(cmd, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, timeout=120)
    report['events'].append({'kind': 'build', 'label': label, 'command': cmd, 'exitCode': result.returncode,
                             'log': str(logfile.relative_to(ROOT))})
    save()
    if result.returncode:
        raise RuntimeError('unexpected build failure: ' + label)

def cases(label, expected_exit, hit_reach):
    for scenario, expected_reach in (('corrected-origin-reach-hit', hit_reach),
                                     ('corrected-origin-reach-miss', not hit_reach)):
        logfile = OUT / (label + '-' + scenario + '.stdout.log')
        native = OUT / (label + '-' + scenario + '.godot.log')
        cmd = [os.environ['GODOT'], '--headless', '--path', str(ROOT), '--log-file', str(native),
               'res://tests/integration/BlockTurnoverTest.tscn', '--', '--harness-scenario=' + scenario]
        with logfile.open('w', encoding='utf-8') as stream:
            result = subprocess.run(cmd, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, timeout=40)
        text = logfile.read_text(encoding='utf-8', errors='replace')
        origin_lines = [line for line in text.splitlines() if 'actual release origin=' in line]
        actual_reach = None
        if len(origin_lines) == 1:
            actual_reach = origin_lines[0].split('actualOriginWithinReach=')[-1].strip().rstrip('.') == 'True'
        event = {'kind': 'case', 'label': label, 'scenario': scenario, 'exitCode': result.returncode,
                 'expectedExitCode': expected_exit, 'expectedActualOriginReach': expected_reach,
                 'observedActualOriginReach': actual_reach, 'actualOriginLines': origin_lines,
                 'outcomeLines': [line for line in text.splitlines() if '[block-turnover] PASS' in line
                                  or '[block-turnover] FAIL' in line or '[block-turnover] RESULT' in line],
                 'log': str(logfile.relative_to(ROOT)), 'nativeLog': str(native.relative_to(ROOT)),
                 'command': cmd}
        report['events'].append(event)
        save()
        print(label, scenario, 'exit', result.returncode, 'actual reach', actual_reach, flush=True)
        if result.returncode != expected_exit or actual_reach is not expected_reach:
            raise RuntimeError('unexpected mutation/control outcome: ' + scenario)

original = SOURCE.read_bytes()
snapshot = OUT / 'BallController-before-origin-mutation.cs.bytes'
snapshot.write_bytes(original)
needle = b'\t\tApplyShotGather(holderBody);'
assert original.count(needle) == 1
mutated = original.replace(needle, b'\t\t// MUTATION #442: retain the old fixed Held station.')
report.update(source=str(SOURCE.relative_to(ROOT)), sourceBeforeSha256=sha(original),
              sourceMutationSha256=sha(mutated), sourceSnapshot=str(snapshot.relative_to(ROOT)),
              trackedBeforeSha256=sha(subprocess.check_output(['git', 'show', 'HEAD:scripts/Ball/BallController.cs'], cwd=ROOT)))
save()
SOURCE.write_bytes(mutated)
try:
    build('old-fixed-station')
    cases('old-fixed-station', 1, False)
finally:
    if SOURCE.read_bytes() != mutated:
        raise RuntimeError('source changed externally during mutation; exact restoration requires reconciliation')
    SOURCE.write_bytes(original)
    report['sourceRestoredSha256'] = sha(SOURCE.read_bytes())
    report['exactSourceBytesRestored'] = SOURCE.read_bytes() == snapshot.read_bytes()
    save()
    build('restored-corrected-origin')

cases('restored-corrected-origin', 0, True)
report['result'] = 'passed'
save()
print('[mutation] PASS reciprocal old-origin failures, exact-byte restore, restored green cases; report=' + str(LEDGER))
